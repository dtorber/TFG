import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd
import os

# abrir todos los archivos del directorio actual con extension .txt
for file in os.listdir(os.getcwd()):
    if file.endswith(".txt"):
        with open(os.path.join(os.getcwd(), file), "r") as f:
            # Leer el archivo y convertirlo en una lista
            data = f.read().splitlines()
            matrix = list()
            for line in data:
                matrix.append(list())
                for value in line.split():
                    matrix[-1].append(float(value))

            columnes = [f"CA0{i + 1}" for i in range(len(matrix[0]))]
            idxs = [f"CA0{i + 1}" for i in range(len(matrix))]
            # Convertir la matriz en un DataFrame de Pandas
            df = pd.DataFrame(
                matrix,
                columns=columnes,
                index=idxs,
            )

            # Crear el mapa de calor usando seaborn
            plt.figure(figsize=(8, 6))  # Tamaño de la figura
            sns.heatmap(
                df, annot=True, cmap="coolwarm", fmt=".2f"
            )  # Crear mapa de calor con anotaciones y formato decimal
            # plt.show()  # Mostrar el mapa de calor
            plt.savefig(f"{file}.png")  # Guardar el mapa de calor en un archivo
